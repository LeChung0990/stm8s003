#include "stm8s.h" 

void delay_config(void);
void delay_ms(unsigned int  u16Delay);