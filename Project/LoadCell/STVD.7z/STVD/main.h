/**
  ******************************************************************************
  * Ten Tep      :        main.h
  * Tac Gia      :        www.hocdientu123.vn
  * Ngay         :        01-08-2019
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H
#include <stdlib.h>
#include "stm8s.h"
#include "stm8s_delay.h"
#include "stm8s_it.h"
#include "stm8s_exti.h"
/* Private define ------------------------------------------------------------*/

#endif /* __MAIN_H*/

/******************* END OF FILE****/