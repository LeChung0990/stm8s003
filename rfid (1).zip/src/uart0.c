/* uart0.c */
#include "n76e003.h"
#include "uart0.h"

void UART0_Init(void)
{
	/* baud rate Timer 1 */
	T3CON &= ~(1 << 5);
	/* init timer 1 mode 2*/
	TMOD &= ~(1 << 4);
	TMOD |= (1 << 5);
	/* T1M */
	CKCON |= (1 << 4);
	/* C/T */
	TMOD &= ~(1 << 6);
	/* Gate */
	TMOD &= ~(1 << 7);
	/* T1OE */
	CKCON &= ~(1 << 5);
	/* Interrupt */
	ET1 = 0;
	/* start timer 1 */
	TH1 = 0xcc;
	TR1 = 1;
	PCON &= ~(1 << 7);
	/* GPIO */
	P06 = 1;
	P0M1 &= ~(1 << 6);
	P0M2 |= (1 << 6);
	P07 = 1;
	P0M1 &= ~(1 << 7);
	P0M2 &= ~(1 << 7);
	/* uart 0 */
	PCON &= ~(1 << 6);
	SM0 = 0;
	SM1 = 1;
	/* enable */
	REN = 1;
}

void UART0_SendData(uint8_t u8Data)
{
	SBUF = u8Data;
}

uint8_t UART0_GetData(void)
{
	return SBUF;
}

void UART0_EnableInterrupt(void)
{
	ES = 1;
}

void UART0_DisableInterrupt(void)
{
	ES = 0;
}

void UART0_ClearFlag(uint8_t u8Flag)
{
	SCON &= ~(u8Flag);
}

uint8_t UART0_GetFlag(uint8_t u8Flag)
{
	if (SCON & (u8Flag)) {
		return 1;
	} else {
		return 0;
	}
}
