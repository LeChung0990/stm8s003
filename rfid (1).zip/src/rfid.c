#include "rfid.h"

static void tim0_set_value(uint16_t u16Value);
static uint16_t tim0_get_value(void);
static void delay1ms(void);
static uint8_t unpack(uint16_t u16Data)
{
	uint8_t u8TmpL;
	uint8_t u8TmpH;
	
	u16Data >>= 1;
	u8TmpL = (uint8_t)u16Data;
	u8TmpL &= 0x0F;
	u16Data >>= 5;
	u8TmpH = (uint8_t)u16Data;
	u8TmpH &= 0x0F;
	u8TmpH <<= 4;
	u8TmpH |= u8TmpL;
	return u8TmpH;
}

#define RF_IN RFID_IN_VAL

void rfid_init(void)
{
	/* P1.0 input */
	P1M1 |= (1 << 0);
	P1M2 &= ~(1 << 0);
	
	CKCON |= (1 << 3); // T0M = 1
	TMOD |= 1; // Timer 0 mode 1, 16 bit
    
    CLRPWM = 1;
	CKCON &= ~(1 << 6);
	PWMCON1 &= 0x07;
	PWMCON1 |= 0x00;
	PWMPH = 0x0;
	PWMPL = 0x7f;
	PWM0H = 0x0;
	PWM0L = 0x40;
	P1M1 &= ~(1 << 2);
	P1M2 |= (1 << 2);
	PIOCON0 |= (1 << 0);
	PWMRUN = 1;
	
	TR0 = 1;
}

static uint8_t u8TimeOut;
static uint8_t u8LastBit;
static uint8_t u8Pack;
static uint8_t u8Tmp;
static uint16_t u16Tmp;
static uint16_t u16Data[4];
static uint8_t i;

uint8_t rfid_decode(uint8_t *pData)
{
	if (RF_IN) {
		return 0;
	}
	tim0_set_value(0x0000);
	u8TimeOut = 0;
	while (1) {
		if (RF_IN) {
			break;
		}
		if (tim0_get_value() > 9600) {
			u8TimeOut = 1;
			break;
		}
	}
	if (u8TimeOut) {
		return 0;
	}
	if (tim0_get_value() < /*6400*/3200) {
		return 0;
	}
	
	tim0_set_value(0x0000);
	u8TimeOut = 0;
	while (1) {
		if (!RF_IN) {
			break;
		}
		if (tim0_get_value() > 9600) {
			u8TimeOut = 1;
			break;
		}
	}
	if (u8TimeOut) {
		return 0;
	}
	if (tim0_get_value() < 6400) {
		return 0;
	}
	for (i = 0; i < 8; ++i) {
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		while (1) {
			if (RF_IN) {
				break;
			}
			if (tim0_get_value() > 4800) {
				u8TimeOut = 1;
				break;
			}
		}
		if (u8TimeOut) {
			return 0;
		}
		if (tim0_get_value() < 3200) {
			return 0;
		}
		
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		while (1) {
			if (!RF_IN) {
				break;
			}
			if (tim0_get_value() > 4800) {
				u8TimeOut = 1;
				break;
			}
		}
		if (u8TimeOut) {
			return 0;
		}
		if (tim0_get_value() < 3200) {
			return 0;
		}
	}
	
	/* version */
	u8LastBit = 1;
	u16Tmp = 0;
	for (i = 0; i < 10; ++i) {
		u16Tmp <<= 1;
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		if (u8LastBit) {
			/* now RF = 0 */
			while (1) {
				if (RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 0 */
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 0;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 1 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			}
		} else {
			/* now RF = 1 */
			while (1) {
				if (!RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 1 */
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 0 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 0;
			}
		}
	}

	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	
	/* byte 3 */
	u16Tmp = 0;
	for (i = 0; i < 10; ++i) {
		u16Tmp <<= 1;
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		if (u8LastBit) {
			/* now RF = 0 */
			while (1) {
				if (RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 0 */
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 0;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 1 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			}
		} else {
			/* now RF = 1 */
			while (1) {
				if (!RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 1 */
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 0 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 0;
			}
		}
	}
	u16Data[3] = u16Tmp;
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	
	/* byte 2 */
	u16Tmp = 0;
	for (i = 0; i < 10; ++i) {
		u16Tmp <<= 1;
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		if (u8LastBit) {
			/* now RF = 0 */
			while (1) {
				if (RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 0 */
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 0;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 1 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			}
		} else {
			/* now RF = 1 */
			while (1) {
				if (!RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 1 */
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 0 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 0;
			}
		}
	}
	u16Data[2] = u16Tmp;
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	
	/* byte 1 */
	u16Tmp = 0;
	for (i = 0; i < 10; ++i) {
		u16Tmp <<= 1;
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		if (u8LastBit) {
			/* now RF = 0 */
			while (1) {
				if (RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 0 */
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 0;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 1 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			}
		} else {
			/* now RF = 1 */
			while (1) {
				if (!RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 1 */
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 0 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 0;
			}
		}
	}
	u16Data[1] = u16Tmp;
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	
	/* byte 0 */
	u16Tmp = 0;
	for (i = 0; i < 10; ++i) {
		u16Tmp <<= 1;
		tim0_set_value(0x0000);
		u8TimeOut = 0;
		if (u8LastBit) {
			/* now RF = 0 */
			while (1) {
				if (RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 0 */
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 0;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 1 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			}
		} else {
			/* now RF = 1 */
			while (1) {
				if (!RF_IN) {
					break;
				}
				if (tim0_get_value() > 4800) {
					u8TimeOut = 1;
					break;
				}
			}
			if (u8TimeOut) {
				/* check next bit = 1 */
				u8TimeOut = 0;
				while (1) {
					if (!RF_IN) {
						break;
					}
					if (tim0_get_value() > 9600) {
						return 0;
					}
				}
				if (tim0_get_value() < 6400) {
					return 0;
				}
				u8LastBit = 1;
				u16Tmp |= 0x01;
			} else {
				if (tim0_get_value() < 3200) {
					return 0;
				}
				/* check next bit = 0 */
				tim0_set_value(0x0000);
				u8TimeOut = 0;
				while (1) {
					if (RF_IN) {
						break;
					}
					if (tim0_get_value() > 4800) {
						return 0;
					}
				}
				if (tim0_get_value() < 3200) {
					return 0;
				}
				u8LastBit = 0;
			}
		}
	}
	u16Data[0] = u16Tmp;
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	/* check pack */
	if (u16Tmp & 0x01) {
		u8Pack = 1;
	} else {
		u8Pack = 0;
	}
	u8Tmp = 0;
	u16Tmp >>= 1;
	for (i = 0; i < 4; ++i) {
		if (u16Tmp & 0x01) {
			u8Tmp ^= 0x01;
		}
		u16Tmp >>= 1;
	}
	if (u8Pack != u8Tmp) {
		return 0;
	}
	
	/* return value */
	u16Tmp = u16Data[3];
	u8Tmp = unpack(u16Tmp);
	pData[3] = u8Tmp;

	u16Tmp = u16Data[2];
	u8Tmp = unpack(u16Tmp);
	pData[2] = u8Tmp;
	
	u16Tmp = u16Data[1];
	u8Tmp = unpack(u16Tmp);
	pData[1] = u8Tmp;
	
	u16Tmp = u16Data[0];
	u8Tmp = unpack(u16Tmp);
	pData[0] = u8Tmp;
	
	return 1;
}

void tim0_set_value(uint16_t u16Value)
{
	TL0 = (uint8_t)u16Value;
	TH0 = (uint8_t)(u16Value >> 8);
}

uint16_t tim0_get_value(void)
{
	return TH0 * 256 + TL0;
}

void delay1ms(void)
{
	TR0 = 0;
	TH0 = 0;
	TL0 = 0;
	TR0 = 1;
	while (TH0 * 256 + TL0 < 16000) {
	}
}

void delay_ms(unsigned int uDelay)
{
	while (uDelay) {
		--uDelay;
		delay1ms();
	}
}