#ifndef RFID_H_
#define RFID_H_

#include "n76e003.h"
#include <stdint.h>

#define RFID_IN_VAL P10

void rfid_init(void);
uint8_t rfid_decode(uint8_t *pData);
void delay_ms(unsigned int uDelay);

#endif
