#include "n76e003.h"
#include <stdint.h>
#include "rfid.h"
#include "uart0.h"

void main(void)
{ 
    uint8_t rfidData[4];
	uint8_t i;
	
	/* P1.5 */
	/* Push-pull */
	P1M1 &= ~(1 << 5);
	P1M2 |= (1 << 5);
	
	P15 = 0;
	
	UART0_Init();
    rfid_init();
    while (1) {
		if (rfid_decode(rfidData)) {
			P15 ^= 1;
			for (i = 0; i < 4; ++i) {
				UART0_SendData(rfidData[3 - i]);
				while (UART0_GetFlag(UART0_TX_FLAG) == 0) {
				}
				UART0_ClearFlag(UART0_TX_FLAG);
			}
			delay_ms(500);
		}
    }
}
